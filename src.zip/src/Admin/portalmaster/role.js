const Employee = [
  {
      "id":"1",
      "company":"CRM",
      "role":"disable"
  },

  {
    "id":"2",
    "company":"erp",
    "role":"disable"
},

{
  "id":"3",
  "company":"live",
  "role":"enable"
},

{
  "id":"4",
  "company":"info",
  "role":"disable"
},
{
  "id":"5",
  "company":"CRM",
  "role":"disable"
},
  
  
]
export default Employee;