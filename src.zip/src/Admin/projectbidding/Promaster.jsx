const Promaster = [
    {   
        "id":"1",
        "project_title":"admin page",
        "portal":"CRM",
        "project_url":"finolity@123.com",
        "estimated_time":"6:00",
        "estimated_cost":"4000",
        "remark":"5"
        
    },
    {   
        "id":"2",
        "project_title":"hr page",
        "portal":"erp",
        "project_url":"mmdu123.com",
        "estimated_time":"7:00",
        "estimated_cost":"5000",
        "remark":"3"
        
    },
    {   
        "id":"3",
        "project_title":"role page",
        "portal":"CRM",
        "project_url":"mmec@123.com",
        "estimated_time":"2:00",
        "estimated_cost":"2000",
        "remark":"7"
        
    },
    {   
        "id":"4",
        "project_title":"position page",
        "portal":"CRM",
        "project_url":"bca@123.com",
        "estimated_time":"1:00",
        "estimated_cost":"1000",
        "remark":"34"
        
    },
    {   
        "id":"5",
        "project_title":"admin page",
        "portal":"CRMO",
        "project_url":"mca@123.com",
        "estimated_time":"6:00",
        "estimated_cost":"4000",
        "remark":"50"
        
    },
    
  ]
  export default Promaster;